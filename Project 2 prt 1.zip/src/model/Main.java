package model;

public class Main {
    RITQTNode root;

    public Main(RITQTNode root) {
        this.root = root;
    }
}
